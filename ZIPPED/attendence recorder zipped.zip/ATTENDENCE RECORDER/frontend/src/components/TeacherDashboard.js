import React from 'react';
import AllStudentsAttendance from './AllStudentsAttendance';

const TeacherDashboard = () => {
  return (
    <div>
      <AllStudentsAttendance />
    </div>
  );
};

export default TeacherDashboard;